/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package courseproject;

import secondpackage.MyClass;

/**
 *
 * @author Christoph
 */
public class SecondClass extends MyClass {
    
    private int classVariable;
    
    public int getClassVariable() {
        return classVariable;
    }
    
    public void setClassVariable(int value){
        if (value > 10)
            return; 
        this.classVariable = value;
    }
    
}
